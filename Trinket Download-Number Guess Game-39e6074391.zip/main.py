import random
n = random.randint(1,75) #generates a random integer in the range of 1 to 75
guess = int(raw_input("Enter an integer from 1 to 75: ")) #asks the player's guess
attempts = 1 #this variable will store number of attempts
while attempts > 0:
  if guess > 75 or guess <= 0: #warns of unwanted input
    print "Please enter a valid number."
    guess = int(raw_input("Enter an integer from 1 to 75: "))
  elif guess == n: 
    print "You Guessed It"
    break   #when guessed correctly the loop will close
  elif guess > n:
    print "Your guess is too high"
    guess = int(raw_input("Enter an integer from 1 to 75: "))
  elif guess < n:
    print "Your guess is too low"
    guess = int(raw_input("Enter an integer from 1 to 75: "))
  attempts = attempts + 1  #counts number of guesses
  print "Your attempts: %s" %(attempts)